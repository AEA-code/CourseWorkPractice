/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

/*A program that compute the remaining balance after fixed and variable expenses are deducted */

#include <stdio.h>
int main()
{
    
//Declare variable 
    float Income=0.0;
    float FixedExpense=0.0;
    float VariableExpense=0.0;
    float TotalExpenses=0.0;
    float BalanceRemaining =0.0; 
    int nfixed,i, nvariable;
    float FSum = 0.0;// initialize fixed and variable expenses to zero
    float VSum = 0.0;
    
    printf("Enter your monthly income\n");
    scanf("%f", &Income);
    
// calculate the total fixed expenses 
    printf("Enter the number of Fixed expenses\n");
    scanf("%d", &nfixed);
    for (i=1; i<=nfixed; i++)
    {
        printf("Enter fixed expense %d:", i);
        scanf("%f", &FixedExpense);
        FSum += FixedExpense;
    }
    
//calculate the total variable expenses 
    printf("Enter the number of variable expense\n");
    scanf("%d", &nvariable);
    for (i=1; i<=nvariable; i++)
    {
        printf("Enter variable expense %d:", i);
        scanf("%f", &VariableExpense);
        VSum += VariableExpense;
    }
    
//calculate total expenses and balance remaining 
    TotalExpenses = FSum + VSum;
    BalanceRemaining = Income - TotalExpenses;
    
// display total expenses and the balance to the user
    printf("Total fixed expenses = %.2f\n", FSum);
    printf("Total variable expenses = %.2f\n", VSum);
    printf("Total expenses =%2.f\n", TotalExpenses);
    printf("BalanceRemaining =%.2f\n", BalanceRemaining);
    
    
// Input validation 
    if (nfixed < 0 || nvariable < 0)
    {
        printf("Number of expenses cannot be negative\n");
        return 1;
    }


// validating the balance remaining 
    if (BalanceRemaining < 0)
    {
        printf("Warning: your expenses exceeded your monthly budget\n");
    }
    else
    {
        printf("You are within your monthly budget\n");
    }
    
    return 0;
}