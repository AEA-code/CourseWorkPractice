/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   float price, Discount;
   printf("Enter the Price: ");
   scanf("%f", &price);
   
   if (price <= 0)
   {
       printf("Exit\n");
   }
   else if (price < 100)
   {
       Discount = price * 0.12;
   }
   else
   {
       Discount = price * 0.18;
   }
   printf("Discount = %2.f\n", Discount);
   printf("Net price = %.2f\n", price - Discount);

    return 0;
}