class program:
    def __init__(self):
        self.data1 = ['Upeople','MIT','UCC','MSC']

    def show(self):
        print('Program details')
        for a in self.data1:
            print(a)
