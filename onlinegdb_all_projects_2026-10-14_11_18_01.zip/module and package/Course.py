class Course:
    def __init__(self):
        self.data2 = ['ONL','BOTH','IT']

    def show(self):
        print('Course details')
        for b in self.data2:
            print(b)
