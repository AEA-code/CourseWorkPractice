# modules
# import math
# print("natural log",math.log(45))
# print("Standard log", math.log10(84))
# print("Power value",math.pow(3,2))
# print("Ceiling function",math.ceil(6.75))
# print("Floor function",math.floor(4.97))
# print("Exponential",math.exp(2))

# # date modules
# from datetime import date
# import datetime
# today = date.today()
# print(today)
# print("Year",today.year)
# print("Month",today.month)
# print("Day",today.day)
# print()

# import datetime

# date_time = datetime.datetime.fromtimestamp(1974527467)
# print(date_time)

# import time
# a = time.time()
# import datetime
# b = datetime.datetime.fromtimestamp(a)
# print(a,"-----",b)

# import os
# os.mkdir("Detail")

# with open("Program.py", "w") as f:
#     f.write(
#         "class program:\n"
#         "    def __init__(self):\n"
#         "        self.data1 = ['Upeople','MIT','UCC','MSC']\n\n"
#         "    def show(self):\n"
#         "        print('Program details')\n"
#         "        for a in self.data1:\n"
#         "            print(a)\n"
#     )



with open("Course.py", "w") as g:
    g.write(
        "class Course:\n"
        "    def __init__(self):\n"
        "        self.data2 = ['ONL','BOTH','IT']\n\n"
        "    def show(self):\n"
        "        print('Course details')\n"
        "        for b in self.data2:\n"
        "            print(b)\n"
    )




















