/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
/*computing the commission of salemen in a firm base on rate*/

    float sales, commission, total;
    int category;
    printf(" Enter your sales amount: ");
    scanf("%f", &sales);
    
    if (sales <= 5000)
    {
        category = 1;
    }
    else if(sales <= 10000)
    {
        category=2;
    }
    else if (sales<= 20000)
    {
        category=3;
    }
    else if (sales<= 25000)
    {
        category=4;
    }
    else
    {
        category=5;
    }
    
    switch (category)
    {
        case 1:
        commission = sales * 0.07;
        break;
        
        case 2:
        commission= sales * 0.09 + 500;
        break;
        
        case 3:
        commission = sales * 0.11 + 1000;
        break;
        
        case 4:
        commission= sales*0.13 + 20000;
        break;
        
        case 5:
        commission= sales*0.15 + 4000;
        break;
        
        default:
        printf("Invalid Input\n");
        
    }
    printf("Your commission is %.2f\n.", commission);
    printf("Your total pay is %.2f\n.", sales + commission);

    return 0;
}
