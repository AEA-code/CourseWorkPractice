# class Course:
#     "The python programming language"
#     lec = 30
#     enroll = 89
#     def fun(self):
#         print("Lecture on Python")
        
# # print(Course.lec)
# # print(Course.__doc__)
# # print(Course.fun)

# #Accesing variables
# details = Course()
# print(details.lec)
# print(details.enroll)
# print(details.fun())
# print(details.__doc__)
# print()
# print("____After deleting____")
# del Course.lec
# print(details.enroll)

# print(del details)

#Data abstracton

# class Course:
#     "Python object oriented programming"
#     lec = 25
#     enroll = 81
#     __year = 2026
    
#     def fun(self):
#         print("Numberof schedule lecture: ",self.lec)
#         print("enroll student: ",self.enroll)
#         print("Year:",year)

# details = Course()
# print(details.lec)
# print(details.enroll)
# print(details.year)


# #Define a class
# class Course:
#     #Defining constructor
#     def __init__(self,l,e,s):
#         self.lec = l
#         self.enroll = e
#         self.sub = s
#     # Define a function
#     def fun(self):
#         print("No. of schedule lecture: ",self.lec)
#         print("No. of enroled student: ",self.enroll)
#         print("Subject:",self.sub)
#     # Object creation and passing argument
# d_1 = Course(30,200,"Python")
# d_2 = Course(45,150,"c++")
    
# # Accesing class attribute and method through Object
# d_1.fun()
# d_2.fun()



# Creating a class for employee

# class Employee:
    
#     def __init__(self,first,second,pay):
#         self.firstname = first
#         self.secondname = second
#         self.payment = pay
#         self.email = first + second + "@gmail.com"
        
#     def fullname(self):
#         return "{} {}".format(self.firstname,self.secondname)
# E_1 = Employee("Elolo","Abednego",15000)
# E_2 = Employee("Peter","Kwojo",3000)
# E_3 = Employee("Mike","Emmanuel",4000)

# print("Full name:",E_1.fullname())
# print("Email:",E_1.email)

# print()
# list_all = [E_1,E_2,E_3]
# for emp in list_all:
#     print("fullname:",emp.fullname())


# parameterized constructor

# class paracons:
    
#     def __init__(self,arg1):
#         print("The parameterized constructor")
#         self.arg1 = arg1
        
#     def show(self,adv):
#         print("John went", self.arg1,adv)
        
# d1 = paracons("school")
# d1.show("today")



