# class test:
#     chk = "Undone"
    
#     def assign(self):
#         print(self.chk)
# v1 = test()
# v1.assign()


# ## single inheritance
# # creating base class
# class student:
    
#     def course(self,arg1):
#         print("---Base class Function---")
#         self.arg1 = arg1
#         print("Course enroll",self.arg1)

# #creating a derive class
# class enroll(student):
    
#     def is_enroll(self,arg2):
#         print("---Derive class Function---")
#         self.arg2 = arg2
#         print("Enrollment course:",self.arg2)
# enr = enroll() # An object for derive class
# enr.is_enroll("Elolo")
# print()
# enr.course("Python")



# ## Multi-Level inheritance
# # base class
# class Electronic:
    
#     def __init__(self):
#         print("---Base Constructor---")
        
#     def call(self,category):
#         print("---Base class---")
#         self.category = category
#         print("Electronic",self.category)

# # Intermediate class        
# class Television(Electronic):
    
#     def is_style(self,style):
#         self.style = style
#         print("---Intermediate derive---")
#         print("Television",self.style)

# # Derive class
# class model(Television):
    
#     def model_name(self,name):
#         self.name = name
#         print("---Derive class---")
#         print("model",self.name)

# s1 = model()
# print()
# s1.call("Portable")
# print()
# s1.is_style("LCD")
# print()
# s1.model_name("Samsung")

# Multiple inheritance

class shoes():
    def __init__(self):
        pass
    
    def make(self,category):
        print("---Category---")
        self.category = category
        print("The category is ",self.category)
        
class cloth():
    def brand(self,brandname):
        print("----Cloth----")
        self.brandname = brandname
        print("The brand name is ",self.brandname)
        
class dress(shoes,cloth):
    def model(self,modelname):
        print("---Model---")
        self.modelname = modelname
        print("The model is ",self.modelname)
        
        
m1 = dress()
m1.make("LLC")
m1.brand("OOP")    
m1.model("Elolo")
print()

print(issubclass(shoes,dress))
print(issubclass(dress,cloth))
print(issubclass(dress,shoes))
print()

print(isinstance(m1,shoes))
print(isinstance(m1,cloth))
print(isinstance(m1,dress))

print(m1.__doc__)
print(m1.__init__)
print(m1.__hash__)
print(m1.__module__)
print(m1.__dict__)
print(dress.__bases__)
print(cloth.__name__)