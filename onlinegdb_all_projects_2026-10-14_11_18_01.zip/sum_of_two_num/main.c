/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    // computing the sum of two number from the user
    
    int num1, num2;
    printf(" Enter the two number: ");
    scanf("%d\n", &num1);
    scanf("%d\n", &num2);
    printf("sum = %d, %d", num1 + num2);

    return 0;
}