/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Hello World\n");
    printf("My name is Elolo\n");
    printf("I am learning c\n");




    int age, favorite;
    
    printf("Enter your age: ");
    scanf("%d", &age);
    
    printf("Enter your favorite number\n");
    scanf("%d", &favorite);
    
    printf("You are %d years old and your favorite number is %d.\n", age, favorite);
    
    int num1, num2;
    
    printf("Enter two number: ");
    scanf("%d, %d", &num1, &num2);
    
    printf("sum = %d\n", num1, num2);
    
    return 0;
}