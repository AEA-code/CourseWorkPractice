
# # Opening a file in write mode
# with open("Myfile.txt", "w") as obj:
#     obj.write("Hello Python!\n")

# #check if the file is writing successfully
# if obj:
#     print("File writing successful")

# # Opening the file in append mode
# with open("Myfile.txt", "a") as obj:
#     obj.write("Python is a programming language.\n")
#     obj.write("Python is programmer's choice.\n")
#     obj.write("Python is beginner friendly.\n")

# # Opening the file in read mode
# with open("Myfile.txt", "r") as obj:
#     print(obj.read())
    

# # using writeliness function for a list of string
# # create a file called book
# with open("Python.txt","w") as book:
#     book.write("Hello\n")
#     # using writeliness function
#     you=["My name is Avorkpo Elolo Abednego\n","I am learning file handling in Python programming language\n","It is easy as you commence\n","I further welcome everyone who is interested in learning it to stage\n"]
#     book.writelines(you)
    
# with open("Python.txt","r") as book:
#     print(book.read())
    
    
# # writing numbers to File
# a=range(0,1000)
# # open file to write
# with open("Numeral.txt","w") as numbers:
#     for num in a:
#         numbers.write(str(num) + " ")
        
# # open file to read
# with open("Numeral.txt","r") as numbers:
#     print(numbers.read())

# # open file to write 
# with open("demo.txt","w") as file:
#     file.write("welcome to Demo text\n")
#     my=["Python is open source\n","It is dinamically typed\n","It is portable\n","It is simple and comprehensive\n"]
#     file.writelines(my)
    
# # open file to read
# with open("demo.txt","r") as file:
#     print(file.read())

# # you can specify the number if character to read by entering the figure like(4)
# with open("demo.txt","r") as file:
#     print(file.readline())# you can specify the number if character to read by entering the figure like(4)

# # using readlines which is the opposite of writelines
# with open("demo.txt","r") as file:    
#     print(file.readlines())

# # open file to write
# with open("demo2.txt","w") as file2:
#     context=["Python was developed in 1989 by Guido van Rossam\n","It integrate all features of the ABC language and few others like extensibility and exception handling\n","Python 1.0 was released in 1994\n","Python 3.9 was released in 2020\n"]
#     file2.writelines(context)

# #open file to read   
# with open("demo2.txt","r") as history:
#     for x in history: # reading contexts with a loop
#         print(x)

# # create a new file
# with open("file.txt","x") as file4:
#     file4.write("You are good")
    
# # create a new file with an existing name
# with open("file.txt","x") as file4:
#     file4.write("My name is Elolo")

# import os.path

# with open("demo.txt","a+") as history:
#     #specifying the required attributes
#     print("Status:",history.closed)
#     print("Name:",history.name)
#     print("Encoding style:",history.encoding)
#     print("Mode:",history.mode)

# # Renaming file
# print("Original file",os.listdir(os.getcwd()))
# old_name= r"/content/demo.txt"
# new_name= r"/content/elolo.txt"
# os.rename(old_name,new_name)
# print("Update is:", os.listdir(os.getcwd))


# # Removing file
# new_name= r"/content/elolo.txt"
# Rename=os.rename(old_name,new_name)
# print("Rename is ",os.listdir(os.getcwd()))


# import os
# print('Original file',os.listdir(os.getcwd()))
# os.remove("/content/demo2.txt")
# print('Update list is:',os.listdir(os.getcwd()))



# # check all file name
# import os
# print(os.getcwd())
# print(os.listdir())

# 

# import os

#Write file
# with open("Elolo.txt", "w") as Abednego:
#     my = [
#         "My name is Kofi\n",
#         "I am currently working as a construction helper\n",
#         "In Civil Power General Contracting(CPC)\n"
#     ]
#     Abednego.writelines(my)


# # Read file
# with open("Elolo.txt", "r") as Abednego:
#     for x in Abednego:
#         print(x) # Display the context

# # Display file list        
# print("Original File is:", os.listdir())

# # Rename file
# os.rename("Elolo.txt", "Demonstration.txt")

# print("Rename is:", os.listdir())

# #Removing file
# os.remove("Demonstration.txt")
# print("Updated file list is:",os.listdir())

# Writing a file consisting of binary numbers
# num=[1,2,3,4,5]

# arr=bytes(num)
# print(arr)

# # write binary file
# with open("demo3.bin","wb") as binary:
#     binary.write(arr)
    
# # Read binary file
# with open("demo3.bin","rb") as binary:
#     binary.read()

# # Open to write file
# with open("demo3.txt","w") as f:
#     f.write("Python tools can be classified into two; General purpose tools and functional tools.\n")
#     f.writelines("Python has full-fledge support for a vast variety of built-in object type.\n")
#     f.writelines("Python considers memory as a private heap.\n")
#     f.writelines("Python community support is quite active and supportive.\n")


# #Open to read file
# with open("demo3.txt","rb") as f:
#     print("Position of pointer:", f.tell())
#     r1=f.readlines()
#     print(r1)
#     print("Position of pointer:",f.tell())
    
#     r2=f.readlines()
#     print(r2)
#     print("Position of pointer:",f.tell())
    
#     r3=f.readlines()
#     print(r3)
#     print("Position of pointer:",f.tell())
    
    
#     #Change cursor position 
#     print("Change cursor position:",f.seek(-15,2))
    


# # Current file directory
# import os 
# print(os.getcwd())
# print()

# #list directory
# data=os.listdir() # list of content from current location
# print(data)
# print(os.listdir("/usr"))
# print()

# #Crearing directories
# os.mkdir("you")
# print(os.listdir()) # list of context

# change directory




# import os

# os.chdir("/user/folder1")
# print(os.getcwd())

# import os
# os.mkdir("dir2")
# print(os.listdir())

# os.chdir("dir2")
# print("After delection:",os.rmdir("dir2"))

# import os 
# os.makedirs("College/Python/Programs")
# print(os.listdir())


# if os.path.exists("College.txt"):
#     print("Path exist")
# else:
#     print("Not exist")


# import os 
# path = os.path.join("College", "Python", "program.py") 
# print(path)


# import os 
# print(os.environ)  

# #Exception handling
# import os # this prevent the finally block or the clean up code from printing
# try:
#     num1 = int(input("Enter the first number: "))
#     num2 = int(input("Enter the second number: "))
    
#     total = num1 / num2
#     print(f"Total division is: {total}")
#     os._exit(1230)
# except ValueError:
#     print("The number sholud be integer")
# finally:
#     print("It is zero division error")























































































