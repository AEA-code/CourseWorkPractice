'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# print ('Hello World')
# a=5
# b=6
# c=7
# s=(a+b+c)/2 #calculate the semi-perimeter
# #Calculate the area
# area= (s*(s-a)*(s-b)*(s-c))**0.5
# print("The area of the triangle is %.2f" %area)

# n= 10
# if n >=0:
#     if n==0: # both statement must be true for the if statement
#         print("n equal zero")
#     else:
#         print("n is positive")
# else:print("n is negative")

print()

# for i in range(0,12):
#     print(i)
    
# mom=[1,2,3,4,5,6,7]
# n=5
# for i in mom:
#     c=n*i
#     print(c)
 
print() 

# i=3
# while (i<20):
#     j=2
#     while (j<=i/j):
#         if not(i%j): break
#         j+=1
#     if (j>i/j):
#         print(i,"is prime")
#     else:
#         print(i,"is not prime")
#     i+=i

print()

# """Calculating the sum with count"""   
# number=[1,2,3,4,5,6,7,8,9]
# total=0
# count=0
# for i in number:
#     total+=i
#     count+=1
#     if count == 6:
#         break
# print("The sum if th first %d natural number is %d" %(count, total))

# determine the prime number
n=99
factor=[]
if n > 1:
    for i in range(1,n+1):
        if n % i == 0:
            factor.append(i)
    print(factor)
    
if len(factor)==2:
    print("Is prime")
else:
    print("Not prime")
            
            



