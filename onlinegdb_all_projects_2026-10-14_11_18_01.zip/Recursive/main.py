# def addition(x,y):
#     total = x + y
#     return total
# print(addition(1,2))
# res = lambda x: x** 2
# print(res(3))

# you = lambda n1,n2,n3: n1 / n2 * n3
# print(you(1,2,3))
# term = int(input("Enter the number of term: "))
# print()
# def fib(k):
#     if k <= 1:
#         return k
#     else:
#         return(fib(k-1) + fib(k-2))

# if term <=0:
#     print("Invalid input!")
# else:
#     print("Fibonacci Series")
#     for i in range(term):
#         print(fib(i))
 
# print()      
# def fact(n):
#     if n<=1:
#         return n
#     else:
#         return n * (fact(n-1))
        
# if term < 0:
#     print("invalid input!")
# elif term == 0:
#     print(f"The factorial of Zero(0) is 1")
# else:
#     print("Factorial")
#     print(f"Factorial of {term} is",fact(term))
 
z=23
def sub(y=3):
    global z
    z=4
    return z
print(sub(z))
print(z)
    