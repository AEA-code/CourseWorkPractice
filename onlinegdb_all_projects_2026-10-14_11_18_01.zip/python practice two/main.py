# c= tuple(["Python Proframing Language",1,2,3,4,5,6])
# b = tuple("Python Lectures")
# print(b[-3:])
# print(tuple(b))
# print(b[:])
# #del b
# #print(b)
# print()
# for a in b:
#     print(a+a)
# print() 
# c= tuple(["Python Proframing Language",1,2,3,4,5,6])

# h = (2,3,4,5,6,7,8,9)
# i = 8
# print(h.index(i,1,9))

# def return_function():
#     t1 = "Python language"
#     x = 56
#     return (t1,x)
# t2 = return_function()
# print(type(t2))
# print(t2)

# e = ("Elolo",[1,2,3],(4,5,6,"Avorkpo Abednego"))
# print(e[0])
# print(e[1])
# print(e[2])

# f = [1,2,34,5,67]
# print(type(f))
# print(type(tuple(f)))


# A = [4,2,5,1,3]
# B =("a","b","c","d","e")
# C = ["Elolo","Avorkpo","Abednego","Mawu","God"]

# result = tuple(zip(A,B,C))
# print(result)
# print()
# print(sorted(A))
# print()
# print(sorted(result))

#  learning dictionary
# you = dict(name = "Elolo",age = 23, Salary = 3000, Address = "Canada")

# print(you)
# print()
# for i in you.items():
#     print(i)
# print()
# your = dict([("name","Elolo"),("age","23"), ("Salary","3000"), ("Address","Canada")])
# print(your)
# print(type(your))
# print()
# #print("Using []:",you["Elolo"]) 
# print("Using get():",your.get("name"))

# youradd = your["name"]="Abednego"
# youradd1 = your["Phnum"]= 586183907
# print("Updating name to:",youradd)
# print("After adding:",your)
# del your["Salary"]
# print("After deleting Salary:",your)

# del your
# del you
# print(you)
# print(your)

# your.clear()
# print("After clearing:",your)

# D2 = dict(sorted(your.items(),reverse=True, key=lambda x:x[0]))
# print("After sorting",D2)


# fname = "you"
# fname += '.jpg'
# print(fname)
# reall = fname[::-1]
# print(reall)

# s = "You're my girlfriend"
# if s[len(s) -3:len(s)] == ".py":
#     print("This is a python programming")


# print(s.capitalize())
# print(s.count("e",0,len(s)))
# print(s.endswith(".py",0,len(s)))
# print(s.find("e.",0,len(s)))
# print(s.islower())
# print(s.isdigit())
# print(s.index("u.",0,len(s)))

# print(s.isspace())
# print(s.upper())
# print(s)
# print(s.isupper())
# print(s.replace("You're my girlfriend","fname"))
# print(s)
# print(s.split(" "))
# print(s.splitlines())

# program = '''list1 = [1,2,3,4,5,6,21,7,8,34,9]
# for i in list1: 
#     print(i, i*2, end=" ")'''
# exec(program)

# b = "You're my girlfriend"
# s = b.encode("utf-8")
# print(s)

# atom = ("Hydrogen",1,"Helium",2,"Lithium",3,"Berrylium",4)
# for i in atom:
#     if isinstance(i,int):
#         j = i*2
#         print(f"Has {i} proton and {j} neutrons")
#     else:
#         print("Element",i)

# printing the number of even perfect square between 0 and 100
# A = ()
# for i in range(0,51):
#     A += (i * 2,)
# print(A)
# print()

# B = ()
# for j in range(0,11):
#     B +=((j*j),)
# print(B)
# print()

# even = ()
# for e in A:
#     if e in B:
#         even += (e,)
# print("Perfect even numbers:", even)


# (a,b,c,d)=(1,2,3,4)
# print(b)


# student=("Elolo","Secterm","GPS-4",1200,1400)
# (name,term,grade,salary,fees) = student

# print(fees)

# ls = [1,2,34,5]
# ls.insert(4,6)
# print(ls)
# ls.append(7)
# print(ls)
# ls1 = [8,9,10,11,12]
# ls.extend(ls1)
# print(ls)
# for i in ls:
#     if 1 in ls:
#         ls.remove(1)
# print(ls)
# print(ls.pop())
# print(ls)
# ls.sort()
# print(ls)
# ls.reverse()
# print(ls)
# con = ls.count(11)
# print(con)
# count = 0
# for i in ls:
#     count += 1
# print(count)
# import random
# al = [random.randint(0,50) for a in range(10)]
# print(al)

# set1 = set(range(0,12))
# print(set1)
# set2 = {2,4,6,8,10}
# print(set2)

# subs = set2 < set1
# ints = set1 & set2
# print(ints)
# un = set1 | set2
# print(subs)
# print(un)
# sub = set1-set2
# print(sub)
# adds = set1.discard(2)
# print(adds)

# from random import *

# roll = list(range(0,13))
# for i in range(0,13):
#     roll[i]=set()


# for i in range(1,7):
#     for j in range(1,7):
#         k = i+j
#         roll[k].add((i,j))

# winner = roll[7]|roll[11]

# losser = roll[2] | roll[3] | roll[12]

# die1 = randrange(1,7)

# die2 = randrange(1,7)

# val = (die1,die2)

# print("Shooter roll",val)

# if val in winner:
#     print("The Shooter wins")
# elif val in losser:
#     print("The Shooter loses")
# else:
#     point = roll[die1+die2]
#     print(die1+die2,"is your point")


# while True:
#     die1 = randrange(1,7)
#     die2 = randrange(1,7)
#     val = (die1,die2)
#     print("roll",val)
    
#     if val in roll[7]:
#         print("The Shooter loses!")
#         break
#     if val in point:
#         print("The Shooter makes the point. A winner!")
#         break






















