# '''

# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.

# '''
# print ('Hello World')
# print()

# print("Python Programming")
# print()


# """This is a comment writen in multiple lines"""
# print("Book for Computer Science")

# #calculating the sum of numbers using functional

# my_list = [2,3,6,7,8,10]
# new_list = list(map(lambda x:x^2+2*x-3,my_list))
# print(my_list, new_list)

# print()
# total=0
# for x in my_list:
#     total+=2*x
# print(total)
# #using imperative
# print()
# def add():
#     total=0
#     for a in my_list:
#         total+=a
#     return
# add()
# print(f"The imperative method sum is {total}")



# # print ('Hello World')

# import re

# p1=re.compile("\w+")
# print(p1.findall("My name is Avorkpo"))
# p2=re.compile("\d+")
# print(p2.findall("I am 22 years old"))
# mylist=[1,2,3,4,5,"Elolo", "%"]
# print(mylist)
# # mylist.clear()
# print(mylist)
# print(mylist.pop())
# del mylist[-1]
# print(mylist)
# mylist.append(44)
# mylist.extend([23,"You",354])
# print(mylist)

# print(mylist[0:4:2])
# print(mylist+[123,321,35])
# mylist[0]=100
# print(mylist)
# mylist.insert(0,"NPP")
# print(mylist)
# """Alaising of list"""
# var1=("you","me","them")
# var2=var1
# print(var1 is var2)
# print(var2==var1)
# print(var1)
# print(var2)
# """Cloning of list"""
# list1=[1,2,3,4]
# list2=list1[:]
# print(list1==list2)
# print(list2 is list1)
# print(list1)
# print(list2)

# '''

# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.

# '''
# print ('Hello World')
# import array
# number=array.array("d",[1,2,3,4,5])
# print(number)
# # indexing,slicing of tuple
# tuple1=(100,)
# tuple2=(100)
# print(type(tuple1))
# print(type(tuple2))
# list1=[12,23,34,45,56]
# numtuple=tuple(list1)
# print(numtuple)
# strtuple=("Python Programming")
# p=tuple(strtuple)
# print(p[7:])
# b=("kofi",[1,2,3,4,5],"Python")
# b[1][4]=51
# print(b)
# c=p + b
# print(c)
# print(len(c[:10]))
# print(c[:2]*2)
# print(max(p))
# print(min(p))
# print(strtuple.count("0"))

# #Tuple assignment
# T1=("Elolo","UAE", 2000, 7000) 

# (EmpName,Country, DOB, Salary)=T1 
# print("Employee Name:",EmpName)
# print("Employee country:",Country)
# print("Emloyee Year of birth:",DOB)
# print("Employee Salary:",Salary)

# # A function receiving a tuple as an argument
# def fun1(*arg):
#     print(type(arg))
#     print(arg)
# t1=("Python is a Programming language")
# fun1(t1)
# #A fnction whic is a tuple returning string and numeric
# def fun_re_num():
#     s1=("Python book")
#     x=2003
#     return(s1,x)
# t2=fun_re_num()
# print(type(t2))
# print(t2)

# Creating dictionary
# fist way
# dict1={}
# dict1["key1"]=[1,2,3,4,5]
# dict1["key2"]=["Kofi","Ama","Kwami","Peter","Elolo"]
# print(dict1)
# print(type(dict1))
# print(dict1["key2"])

# #scond way
# dict2=dict(Name="David",Age=34,Contry="Ghana")
# print(dict2)

# #Third way
# # dict3={
# #     ("Name":"Mensah"),
# #     ("Age":45)
# # }
# # print(dict3)

# dict4={
#     45:"Age",
#     2649:"Elolo",
#     2500:"Mustafa",
#     2650:"Malik",
#     2546:"John",
#     4563:"Mansah"
# }
# # Accessing data in dictionary 
# print(dict4)
# print(dict4[2500])
# # or
# print(dict4.get(2500))

# # modifying dictionary
# print()
# dict4[1222]="You"
# print(f" After first updating {dict4}")
# print()
# dict4[1001]="Manager"
# print(f"After second updating {dict4}")
# print()

# #deleting item
# del dict4[2649]
# print(f"After deleting {dict4}")
# print()
# uu=dict4.pop(1001)
# print(uu)

# # sorting by key
# dict5 = dict(sorted(dict4.items(), key=lambda x: x[0]))
# print(f"After sorting the dictionary:", dict5)

# Clearing all the item in the dictionary
# dict4.clear()
# print(f"After clearing the dictionary:",dict4)

# MY={
#     "Name":34, "Country":12,"Age":35,"AAA":89
# }

# del MY["Country"]
# print(MY)

# uu= MY.pop("you","Not availabe")
# print(uu)

# #sorting by key
# sort=dict(sorted(MY.items(),key=lambda x :x[0]))
# sortrev=dict(sorted(MY.items(),reverse=True,key=lambda x:x[0]))
# print(f"Sorting by key: {sort}")
# print(F"After reversing the dictionary:{sortrev}")
# print(type(sort))
# print()

# #sorting by value
# sortvalue=dict(sorted(MY.items(),key=lambda x:x[1]))
# sortvaluerev=dict(sorted(MY.items(),reverse=True,key=lambda x:x[1]))
# print(f"sorting by value {sortvalue}")
# print(f"After reversing the value order dictionary:{sortvaluerev}")
# print(type(sortvalue))
# print()

# #iterating a dictionary
# for t in MY.items():
#     print(t)
# print() 

# # other means is
# for key,value in MY.items():
#     print(key,value)
#     #print(value,key)
# print()

# # Another way is
# for k in MY.keys():
#     print(k,MY.get(k))

# #nested dictionary
# Emp={
#     "e1":{"Name":"Elolo","Age":22,"Post":"Technical Manager"},
#     "e2":{"Name":"Peter","Age":27,"Post":"Clerk"},
#     "e3":{"Name":"Malik","Age":26,"Post":"HR"}
#     }

# # Displaying the complete dictionary
# print(Emp)
# print()

# # Displaying Details of dictionary one
# print(".....Details for e1 dictionary.....")
# print(Emp["e1"]["Name"])
# print(Emp["e1"]["Age"])
# print(Emp["e1"]["Post"])
# print()

# # Displaying Details of dictionary two
# print(".....Details for e2 dictionary.....")
# print(Emp["e2"]["Name"])
# print(Emp["e2"]["Age"])
# print(Emp["e2"]["Post"])
# print()

# # Displaying Details of dictionary three
# print(".....Details for e3 dictionary.....")
# print(Emp["e3"]["Name"])
# print(Emp["e3"]["Age"])
# print(Emp["e3"]["Post"])
# print()

# # adding subdictionary
# Emp["e4"]={"Name":"Hassan","Age": 21,"Post":"Supervisor"}

# # updating dictionary
# Emp["e1"]={"Name":"Elolo","Age":23,"Post":"Manager"}

# # deleting items
# del Emp["e3"]["Age"]
# print(Emp)
# print()

# #iterating through a nested dictionary
# for detail_id, value in Emp.items():
#     print(f"Dictionary Details Id {detail_id}")
#     print()
#     for key in value:
#         print(key+":",value[key])
#     print(".................................")


# print(len(Emp))
# print(str(Emp)) #converts the dictionary into a string representation.
# print(type(Emp))
# print(any(Emp)) # checks whether at least one item is truthy.
# print(all(Emp)) #checks whether every item is truthy.


# # copying Dictionary
# Dictionary={123:"Mike",124:"John",125:"Mosses"}
# print(f"The original copy of the Dictionary is {Dictionary}")

# # copy version
# Dictionary.copy()
# print(f"The coppy version is:{Dictionary}")
# print()

# # formatting Dictionary
# Diction={"Name":"Elolo","Salary":50000,"Post":"Manager"}
# print(f"Original Dictionary:{Diction}")
# #Formatting Dictionary
# print("...................")
# print("....Formatting dictionary....")
# print("My name is %(Name)s"%Diction)
# print("I earn almost %(Salary).2f every month and my Post is %(Post)s"%Diction)



# # functional Programming
# mylist=[1,2,3,4,5,6,7,8,9,10]
# accu=list(map(lambda x:x + 2*x, mylist))
# print(accu)

# print()
# # imperative Programming
# for i in mylist:
#     i += 2*i 
#     print(i)
# print()

# # procedural Programming
# def add():
#     total= 0
#     for r in mylist:
#         total+=r
#     return total
# print("The total is:",add())


# # Object oriented Programming
# class A:
#     def test(self,a,b,c):
#         return(a+b*c)
# r=A()
# print("Result is =", r.test(1,2,3))
# print()

# # checking data types
# d=2+4j
# print(type(d))
# print("The complex is ", isinstance({"name": 34},dict))


# name=input("Enter your name: ")
# age=int(input("Enter your name: "))
# print(f"Hello your name is {name} and you are {age} years old") 
# # or
# print("Hello your name is %s and you are %i years old" %(name, age))

# def multiple(*numbers):
#     total =1 
#     for number in numbers:
#         total *= number
#     return total
# result = multiple(1,2,3,4,5)
# print(result)

# def save_user(**user):
#     # print(user)
#     return user
# result = save_user(id=12, name="Elolo",job="Data_analyst")
# print(result)

# def fizz_buzz(input):
#     if (input % 3 == 0) and (input % 5 == 0):
#         return "FizzBuzz"
#     if input % 3 == 0:
#         return "Fizz"
#     if input % 5 == 0:
#         return "Buzz"
#     return input
# print(fizz_buzz(7))

# list_type=[-1,11,-100,23,4,1,-3]
# print(type(list_type))
# a = set(list_type)
# print(type(a))
# print(a)
# dict_type = {"name": "Elolo", "Age":19, "Hair":"N/A"}
# print(type(dict_type))
# print(dict_type)
# print(dict_type.items())
# print(dict_type.keys())
# print(dict_type.values())
# long_str = "I love to learn and invest"
# conv_list =list(long_str)
# print(conv_list)
# print(type(conv_list))
# print()
# conv_set =set(long_str)
# print(conv_set)
# print(type(conv_set))

# name = input("Please enter your name: ")
# weight = int(input("Enter your weight in pounds: "))
# print()
# Height = int(input("Enter your Height in inches: "))
# print()
# BIM = (weight  * 703) / (Height * Height )
# print(round(BIM,1))
# print()
# if BIM> 0:
#     if BIM < 18.5:
#         print(name, "You are Underweight")
#     elif BIM <= 24.9:
#         print(name, "You are Normal weight")
#     elif BIM <= 29.9:
#         print(name, "You are Overweight")
#     elif BIM <= 34.9:
#         print(name, "You are Obese-High")
#     elif BIM <= 39.9:
#         print(name, "You are Severely Obese - very High")
#     else:
#         print(name, "You are Over-Morbidly Obese - Extremely High")



















print(10/3)




















