/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   // int num1, num2;
    
  //  printf("Enter two number: ");
  //  scanf("%d %d", &num1, &num2);
   // printf("sum = %d\n", num1 + num2);
   
   // int hours, wage;
   
    //printf("Enter the hours work: ");
  //  scanf("%d", &hours);
  //  if (hours <= 0) {
 //       printf("Stop\n");}
 //   else if (hours >= 80){
 //       printf("Invalid hours\n");}
 //   else if (hours <= 35){
  //      wage = hours*15;}
  //  else if (hours <= 60){
  //      wage = 35*15 + (hours-35)*18;}
  //  else {
   //     wage=35*15 + 25*18 +( hours-60)*25;}
        
   // printf("Your wage is %d\n", wage);
   
  // int num;
  // printf("Enter the number: ");
  // scanf("%d", &num);
   
  // if (num> 0){
  //     printf("It is a positive number %d\n", num);
  // }
  // else if (num == 0){
  //     printf("it is zero %d\n", num);
  // }
  // else {
  //     printf("It is a negative number %d\n");
  // }
  
  /* A program that check if an employee is eligible to work*/
  //int age;
  //printf("Please enter you age: ");
  //scanf("%d", &age);
  //if (age >= 18 && age <= 60){
  //    printf("You are eligible to work\n");
  //}
  //else{
  //    printf("You are not eligible to work\n");
  //}
  
  /* Using switch for multiple conditions instead of if-else*/
  //int operation;
  //printf("Enter a number between 1 and 4: ");
  //scanf("%d", &operation);
  
  //switch (operation){
  //    case 1:
  //    printf("Addition\n");
  //    break;
      
  //    case 2:
  //    printf("Subtraction\n");
  //    break;
      
  //    case 3:
  //    printf("Multiplication\n");
  //    break;
      
  //    case 4:
  //    printf("Division\n");
  //    break;
      
  //    default:
  //    printf("Invalid choice\n");}
  
/* A for loop that displays values from 10 down to 1.
   Note: We use i-- to decrease the counter and >= to keep looping until 1. */
  //int i;
  //for (i=1; i<= 10; i++)
  //{
  //    printf("%d\n", i);
  //}
      
/* A for loop that displays only even numbers less or equal to 20*/
    //int i;
    //for (i = 2; i<= 20; i +=2){
    //    printf("%d\n", i);
    //}
/* While loop to display number in decreasing order   
    //int i=5;
    //while (i>=1){
    //    printf("%d\n",i);
    //    i--;
    //}
/* do..while loop to display number in decreasing order*/

    int i=10;
    do {
        printf("%d\n",i);
        i--;
    } while (i>=1);
  return 0;
}