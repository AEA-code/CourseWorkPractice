'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# print ('Hello World')

# def add(num1,num2):
#     total=num1+num2
#     return total
# total=add(1,2)
# print("The total is %d" %total)

# res=lambda a:a+4
# print(res(5))

# fun=lambda x:x**2+2*x-3
# v=fun(2)
# print(v)

# res= lambda a,b,c,d: 2*a-3*b+5*c+d
# print(res(1,2,3,4))

"""A program for fibonaci series"""

# def fib(a):
#     if a <=1:
#         return a 
#     else:
#         return(fib(a-1)+fib(a-2))
        
# term = 12
# if term <= 0:
#     print("Invalid term")
# else:
#     print("FIbonacci series")
#     for i in range(term):
#         print(fib(i))

""" A recursive program for factorial value"""
# def fact(n):
#     if n==1:
#         return n
#     return n*fact(n-1)

# #validate the input
# m=5
# if m < 0:
#     print("Invalid input!, Please enter a valid input")
# elif m==0:
#     print("The factorial of 0 is 1")
# else:
#     print("The factorial of", m, "is", fact(m))

from time import gmtime
current_time = gmtime()
print("UTC time is", current_time)
print("Current year", current_time.tm_year)
print("Current Month", current_time.tm_mon)
print("Current day", current_time.tm_mday)
print("curent Hour", current_time.tm_hour)
print("current minute", current_time.tm_min)
print("current Second", current_time.tm_sec)

