'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# import re
# check_name = re.compile(r"[^A_Ax_ax]")
# myname = input("Enter your name: ")
# while check_name.search(myname):
#     print("Enter the name corectly")
#     myname = input("Enter your name: ")
#     print(myname)

import re
# mycount = 0
# mypattern = re.compile("10")
# mymatche = mypattern.finditer("100100101001010101011101")
# for loop in mymatche:
#     mycount += 1
#     print("Starting {}; Ending {}; Group {}".format(loop.start(), loop.end(), loop.group()))
#     print(f"Total occurance is {mycount}")

# # Alternative
# import re
# mycount = 0
# mymatcher = re.finditer("10","100100101001010101011101")
# for loop in mymatcher:
#     mycount += 1
#     print("Starting {}; Ending {}; Group {}".format(loop.start(), loop.end(), loop.group()))
#     print(f"Total occurance is {mycount}")


import re
count = 0
mymatcher = re.finditer("[abc]","abtiru487&*#^(x8375ijg")
for loop in mymatcher:
    count += 1
    print(loop.start(),"...",loop.end(),"...",loop.group())
print("______________________")
print()

mymatcher = re.finditer("[^avo]","avorkpo elle") 
for loop in mymatcher:
    print(loop.start(),"...",loop.end(),"...",loop.group())
print("_______________________")
print()

# character class for numeric
mymatcher = re.finditer("[1-9]","1a2a3s4d5f6g7g8h9")
for loop in mymatcher:
    print(loop.start(),"...",loop.end(),"...",loop.group())
print("________________________")

# character class except numeric using ^
mymatcher = re.finditer("[^1-9]","1a2a3s4d5f6g7g8h9")
for loop in mymatcher:
    print(loop.start(),"...",loop.end(),"...",loop.group())
print("_______________________")
print()

mymatcher = re.finditer("[a-z]","a,b,45,6,8,9,3,4,5c,d,e,f,g,h,i,j,k,lm,n,o,p1a2a3s4d5f6g7g8h9")
for loop in mymatcher:
    print(loop.start(),"...",loop.end(),"...",loop.group())





















